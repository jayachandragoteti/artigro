<!--========================================================-->
<section class="map-contact padding-none">
    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3501889.0795673826!2d73.15687918966267!3d31.00357561172526!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x391964aa569e7355%3A0x8fbd263103a38861!2sPunjab!5e0!3m2!1sen!2sin!4v1503422781241" width="100%" height="250" frameborder="0" style="border:0" allowfullscreen=""></iframe>
</section>
<section class="element_page">
    <div class="container">
        <div class="row">
            <div class="col-lg-9 col-md-9 mx-auto">
                <div class="widget widget-margin-top">
                    <div class="section-header section-header-center text-center">
                        <h5 class="text-warning">SINCE <b>2020</b></h5>
                        <h3 class="heading-design-center-h3">
                            ARTIGRO
                        </h3>
                    </div>
                    <div class="section-header section-header-center text-center">
                        <h3 class="heading-design-center-h3">
                        contact information
                        </h3>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque<br> lobortis tincidunt est, et euismod purus suscipit quis. Etiam euismod ornare elementum. </p>
                        <br>
                    </div>
                    <div class="row">
                        <div class="col-lg-12 col-md-9 mx-auto">
                            <div class="row">
                                <div class="col-lg-4 col-md-4">
                                    <div class="about_page_widget widget">
                                        <a href="tel:+91 9491694195" class="text-white"> <i class="icofont icofont-iphone"></i></a>
                                        <h5>Phone</h5>
                                        <h2><a href="tel:+91 9491694195" class="text-white">9491694195</a></h2>
                                    </div>
                                </div>
                                <div class="col-lg-4 col-md-4">
                                    <div class="about_page_widget widget">
                                    <a href="https://www.google.co.in/search?q=aditya+institute+of+technology+and+management&source=hp&ei=M0OJYM34FvSP4-EP9_-zuAE&iflsig=AINFCbYAAAAAYIlRQ0zhqqmzuCanfRKCW2lm0dX9ZhYA&gs_ssp=eJzj4tZP1zcsSUu2zClON2D00k1MySypTFTIzCsuySwpLUlVyE9TKElNzsjLz8lPr1RIzEtRyE3MS0xPzU3NKwEAfm4V1g&oq=aditya+in&gs_lcp=Cgdnd3Mtd2l6EAEYADIFCC4QkwIyAggAMgIIADIICC4QxwEQrwEyCAguEMcBEK8BMggILhDHARCvATICCAAyAggAMgIIADICCAA6BQgAELEDOgsILhCxAxDHARCjAjoICAAQsQMQgwE6CAguEMcBEKMCOggILhCxAxCDAToOCC4QsQMQxwEQowIQkwI6BQguELEDOgsILhCxAxDHARCvAToLCAAQsQMQgwEQyQM6BQgAEJIDOggILhCxAxCTAjoFCAAQyQM6AgguUHRYvxZg-iBoAHAAeACAAZQDiAHMEJIBCTAuMi4zLjIuMZgBAKABAaoBB2d3cy13aXo&sclient=gws-wiz" class="text-white"><i class="icofont icofont-location-pin"></i></a>
                                        <h5>Address</h5>
                                        <h2><a href="https://www.google.co.in/search?q=aditya+institute+of+technology+and+management&source=hp&ei=M0OJYM34FvSP4-EP9_-zuAE&iflsig=AINFCbYAAAAAYIlRQ0zhqqmzuCanfRKCW2lm0dX9ZhYA&gs_ssp=eJzj4tZP1zcsSUu2zClON2D00k1MySypTFTIzCsuySwpLUlVyE9TKElNzsjLz8lPr1RIzEtRyE3MS0xPzU3NKwEAfm4V1g&oq=aditya+in&gs_lcp=Cgdnd3Mtd2l6EAEYADIFCC4QkwIyAggAMgIIADIICC4QxwEQrwEyCAguEMcBEK8BMggILhDHARCvATICCAAyAggAMgIIADICCAA6BQgAELEDOgsILhCxAxDHARCjAjoICAAQsQMQgwE6CAguEMcBEKMCOggILhCxAxCDAToOCC4QsQMQxwEQowIQkwI6BQguELEDOgsILhCxAxDHARCvAToLCAAQsQMQgwEQyQM6BQgAEJIDOggILhCxAxCTAjoFCAAQyQM6AgguUHRYvxZg-iBoAHAAeACAAZQDiAHMEJIBCTAuMi4zLjIuMZgBAKABAaoBB2d3cy13aXo&sclient=gws-wiz" class="text-white">Aitam Tekkali</a></h2>
                                    </div>
                                </div>
                                <div class="col-lg-4 col-md-4">
                                    <div class="about_page_widget widget">
                                        <a href="mailto:artigo.in@gmail.com" class="text-white"><i class="icofont icofont-ui-email"></i></a>
                                        <h5>Email</h5>
                                        <h2><a href="mailto:artigo.in@gmail.com" class="text-white">artigo.in@gmail.com</a></h2>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!--========================================================-->
