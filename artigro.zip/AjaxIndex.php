<!--<div class="osahan-breadcrumb">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="#"><i class="icofont icofont-ui-home"></i> Home</a></li>
                </ol>
            </div>
        </div>
    </div>
</div>
-->
<div id="carouselExampleIndicators" class="carousel slide carousel-fade" data-ride="carousel" style="margin-top:-2.3%">
  <ol class="carousel-indicators">
    <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
  </ol>
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="site/banners/banner  (1).JPG" class="d-block w-100" alt="..." style="height:370px">
    </div>
    <div class="carousel-item">
      <img src="site/banners/banner  (2).JPG" class="d-block w-100" alt="..." style="height:370px">
    </div>
    <div class="carousel-item">
      <img src="site/banners/banner  (3).JPG" class="d-block w-100" alt="..." style="height:370px">
    </div>
  </div>
  <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>

<!-- SECTION -->
<div class="section">
	<!-- container -->
	<div class="container">
	<!-- row -->
		<div class="row ajax_filter_categories_data">
			
		</div>
	<!-- /row -->
	</div>
	<!-- /container -->
</div>
<!-- /SECTION -->
<section class="hot-offers main-bg-color mt-5">
    <div class="container">
      <div class="row">
        <div class="col-lg-6 col-md-6 col-sm-6">
          <div class="carousel-section-header">
            <h5 class="heading-design-h5 pull-left">All Products </h5>
          </div>
        </div>
        <div class="col-lg-6 col-md-6 col-sm-6">
          <a class="btn btn-radius  border-warning pull-right" data-toggle="modal" data-target="#AjaxProductFilterModal" href="#"><i class="fa fa-filter"></i> Filter</a>
        </div>
      </div>
    </div>
  </section>

  <div class="container">
	<!-- row -->
		<div class="row Ajax-Product-Filter">		
		</div>
	<!-- /row -->
	</div>


