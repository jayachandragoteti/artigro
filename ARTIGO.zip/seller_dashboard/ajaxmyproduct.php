<div class="main-panel">
	<div class="container">
		<div class="panel-header">
			<div class="page-inner py-5">
				<div class="row displaymyproducts">
				</div>
			</div>
		</div>
	</div>
			<footer class="footer">
				<div class="container-fluid">
					<nav class="pull-left">
						<ul class="nav">
							
						</ul>
					</nav>
					<div class="copyright ml-auto">
						2021, made with <i class="fa fa-heart heart text-danger"></i> by <a href="#">ThemeKita</a>
					</div>				
				</div>
			</footer>
</div>