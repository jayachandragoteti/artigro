<div class="main-panel" >
	<div class="container">
		<div class="panel-header bg-primary-gradient">
			<div class="page-inner py-5">
				<div class="d-flex align-items-left align-items-md-center flex-column flex-md-row">
				</div>
			</div>
		</div>
			<div class="page-inner mt--5">
				<div class="row mt--2 text-center">
					<div class="col-md-4">
					</div>
					<div class="col-md-4">
						<div class="card full-height">
							<div class="card-body">
								<div class="card-title"><h1>Add Category</h1></div>
									<form method="post">
										<div class="d-flex flex-wrap justify-content-around ">
											<div class="px-2 pb-2 pb-md-0 text-center">
												<div class="form-group">
													<input type="text" class="form-control" name="add_category"id="add_category" placeholder="Enter category name">
												</div>
												<div class="category-alerts">
												</div>
												<input type="button" onclick="AddCategory()" value="Submit">
											</div>
										</div>
									</form>
								</div>
							</div>
						</div>
					</div>
					<div class="col-md-4">
					</div>
				</div>
		
			
				<div class="row mt--2 text-center">
					<div class="col-md-11" style="margin-left:5%;">
					<div class="card" style="cursor:pointer;">
								
								<div class="card-body">
									<table class="table table-hover">
										<thead>
											<tr>
												<th scope="col">SNo</th>
												<th scope="col">Category Name</th>
											
											</tr>
										</thead>
										<tbody class="displaymycategories">
										
										</tbody>
									</table>
								</div>
					</div>
				</div>
				</div>
				<script>
				
					setInterval(function(){ mycategories() ; }, 1000);
					function mycategories() {
						var displaymycategories="displaymycategories";
						$.ajax({
							type:"POST",
							url:"backscript.php",
							data:displaymycategories,
							success:function (responce) {
								$(".displaymycategories").html(responce);
							}
						});
					}

				</script>		
<footer class="footer">
	<div class="container-fluid">
		<nav class="pull-left">
			<ul class="nav">
			</ul>
		</nav>
	<div class="copyright ml-auto">
2021, made with <i class="fa fa-heart heart text-danger"></i> by <a href="#">ThemeKita</a>
		</div>	
	</div>
</footer>
		</div>